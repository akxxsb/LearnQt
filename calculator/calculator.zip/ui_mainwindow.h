/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionAbout;
    QAction *actionAbout_Qt;
    QWidget *centralWidget;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_5;
    QLabel *Ans;
    QGridLayout *gridLayout;
    QPushButton *ButtonAc;
    QPushButton *Num2;
    QPushButton *Num7;
    QPushButton *Num8;
    QPushButton *Num4;
    QPushButton *ButtonAdd;
    QPushButton *Num5;
    QPushButton *Num1;
    QPushButton *ButtonDiv;
    QPushButton *ButtonSub;
    QPushButton *ButtonMul;
    QPushButton *Buttonflag;
    QPushButton *Num9;
    QPushButton *Num3;
    QPushButton *Num6;
    QPushButton *ButtonMod;
    QHBoxLayout *horizontalLayout;
    QPushButton *Num0;
    QPushButton *ButtonPt;
    QPushButton *ButtonEq;
    QMenuBar *menuBar;
    QMenu *menu;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(340, 500);
        QIcon icon;
        icon.addFile(QString::fromUtf8("ico.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setIconSize(QSize(1000, 400));
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QString::fromUtf8("actionAbout"));
        actionAbout_Qt = new QAction(MainWindow);
        actionAbout_Qt->setObjectName(QString::fromUtf8("actionAbout_Qt"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(21, 30, 264, 428));
        verticalLayout_5 = new QVBoxLayout(layoutWidget);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        Ans = new QLabel(layoutWidget);
        Ans->setObjectName(QString::fromUtf8("Ans"));
        Ans->setMinimumSize(QSize(250, 30));
        Ans->setMaximumSize(QSize(360, 20));
        Ans->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_5->addWidget(Ans);

        gridLayout = new QGridLayout();
        gridLayout->setSpacing(20);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        ButtonAc = new QPushButton(layoutWidget);
        ButtonAc->setObjectName(QString::fromUtf8("ButtonAc"));
        ButtonAc->setMinimumSize(QSize(50, 50));
        ButtonAc->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(ButtonAc, 0, 1, 1, 1);

        Num2 = new QPushButton(layoutWidget);
        Num2->setObjectName(QString::fromUtf8("Num2"));
        Num2->setMinimumSize(QSize(50, 50));
        Num2->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(Num2, 1, 2, 1, 1);

        Num7 = new QPushButton(layoutWidget);
        Num7->setObjectName(QString::fromUtf8("Num7"));
        Num7->setMinimumSize(QSize(50, 50));
        Num7->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(Num7, 3, 1, 1, 1);

        Num8 = new QPushButton(layoutWidget);
        Num8->setObjectName(QString::fromUtf8("Num8"));
        Num8->setMinimumSize(QSize(50, 50));
        Num8->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(Num8, 3, 2, 1, 1);

        Num4 = new QPushButton(layoutWidget);
        Num4->setObjectName(QString::fromUtf8("Num4"));
        Num4->setMinimumSize(QSize(50, 50));
        Num4->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(Num4, 2, 1, 1, 1);

        ButtonAdd = new QPushButton(layoutWidget);
        ButtonAdd->setObjectName(QString::fromUtf8("ButtonAdd"));
        ButtonAdd->setMinimumSize(QSize(50, 50));
        ButtonAdd->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(ButtonAdd, 0, 4, 1, 1);

        Num5 = new QPushButton(layoutWidget);
        Num5->setObjectName(QString::fromUtf8("Num5"));
        Num5->setMinimumSize(QSize(50, 50));
        Num5->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(Num5, 2, 2, 1, 1);

        Num1 = new QPushButton(layoutWidget);
        Num1->setObjectName(QString::fromUtf8("Num1"));
        Num1->setMinimumSize(QSize(50, 50));
        Num1->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(Num1, 1, 1, 1, 1);

        ButtonDiv = new QPushButton(layoutWidget);
        ButtonDiv->setObjectName(QString::fromUtf8("ButtonDiv"));
        ButtonDiv->setMinimumSize(QSize(50, 50));
        ButtonDiv->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(ButtonDiv, 3, 4, 1, 1);

        ButtonSub = new QPushButton(layoutWidget);
        ButtonSub->setObjectName(QString::fromUtf8("ButtonSub"));
        ButtonSub->setMinimumSize(QSize(50, 50));
        ButtonSub->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(ButtonSub, 1, 4, 1, 1);

        ButtonMul = new QPushButton(layoutWidget);
        ButtonMul->setObjectName(QString::fromUtf8("ButtonMul"));
        ButtonMul->setMinimumSize(QSize(50, 50));
        ButtonMul->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(ButtonMul, 2, 4, 1, 1);

        Buttonflag = new QPushButton(layoutWidget);
        Buttonflag->setObjectName(QString::fromUtf8("Buttonflag"));
        Buttonflag->setMinimumSize(QSize(50, 50));
        Buttonflag->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(Buttonflag, 0, 2, 1, 1);

        Num9 = new QPushButton(layoutWidget);
        Num9->setObjectName(QString::fromUtf8("Num9"));
        Num9->setMinimumSize(QSize(50, 50));
        Num9->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(Num9, 3, 3, 1, 1);

        Num3 = new QPushButton(layoutWidget);
        Num3->setObjectName(QString::fromUtf8("Num3"));
        Num3->setMinimumSize(QSize(50, 50));
        Num3->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(Num3, 1, 3, 1, 1);

        Num6 = new QPushButton(layoutWidget);
        Num6->setObjectName(QString::fromUtf8("Num6"));
        Num6->setMinimumSize(QSize(50, 50));
        Num6->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(Num6, 2, 3, 1, 1);

        ButtonMod = new QPushButton(layoutWidget);
        ButtonMod->setObjectName(QString::fromUtf8("ButtonMod"));
        ButtonMod->setMinimumSize(QSize(50, 50));
        ButtonMod->setMaximumSize(QSize(50, 50));

        gridLayout->addWidget(ButtonMod, 0, 3, 1, 1);


        verticalLayout_5->addLayout(gridLayout);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(20);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        Num0 = new QPushButton(layoutWidget);
        Num0->setObjectName(QString::fromUtf8("Num0"));
        Num0->setMinimumSize(QSize(120, 50));
        Num0->setMaximumSize(QSize(120, 50));

        horizontalLayout->addWidget(Num0);

        ButtonPt = new QPushButton(layoutWidget);
        ButtonPt->setObjectName(QString::fromUtf8("ButtonPt"));
        ButtonPt->setMinimumSize(QSize(50, 50));
        ButtonPt->setMaximumSize(QSize(50, 50));

        horizontalLayout->addWidget(ButtonPt);

        ButtonEq = new QPushButton(layoutWidget);
        ButtonEq->setObjectName(QString::fromUtf8("ButtonEq"));
        ButtonEq->setMinimumSize(QSize(50, 50));
        ButtonEq->setMaximumSize(QSize(50, 50));

        horizontalLayout->addWidget(ButtonEq);


        verticalLayout_5->addLayout(horizontalLayout);

        MainWindow->setCentralWidget(centralWidget);
        layoutWidget->raise();
        ButtonMod->raise();
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 340, 23));
        menu = new QMenu(menuBar);
        menu->setObjectName(QString::fromUtf8("menu"));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menu->menuAction());
        menu->addAction(actionAbout);
        menu->addAction(actionAbout_Qt);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Qsc's calculator", 0, QApplication::UnicodeUTF8));
        actionAbout->setText(QApplication::translate("MainWindow", "About", 0, QApplication::UnicodeUTF8));
        actionAbout_Qt->setText(QApplication::translate("MainWindow", "About Qt", 0, QApplication::UnicodeUTF8));
        Ans->setText(QString());
        ButtonAc->setText(QApplication::translate("MainWindow", "AC", 0, QApplication::UnicodeUTF8));
        Num2->setText(QApplication::translate("MainWindow", "2", 0, QApplication::UnicodeUTF8));
        Num7->setText(QApplication::translate("MainWindow", "7", 0, QApplication::UnicodeUTF8));
        Num8->setText(QApplication::translate("MainWindow", "8", 0, QApplication::UnicodeUTF8));
        Num4->setText(QApplication::translate("MainWindow", "4", 0, QApplication::UnicodeUTF8));
        ButtonAdd->setText(QApplication::translate("MainWindow", "\357\274\213", 0, QApplication::UnicodeUTF8));
        Num5->setText(QApplication::translate("MainWindow", "5", 0, QApplication::UnicodeUTF8));
        Num1->setText(QApplication::translate("MainWindow", "1", 0, QApplication::UnicodeUTF8));
        ButtonDiv->setText(QApplication::translate("MainWindow", "\303\267", 0, QApplication::UnicodeUTF8));
        ButtonSub->setText(QApplication::translate("MainWindow", "\357\274\215", 0, QApplication::UnicodeUTF8));
        ButtonMul->setText(QApplication::translate("MainWindow", "\303\227", 0, QApplication::UnicodeUTF8));
        Buttonflag->setText(QApplication::translate("MainWindow", "\302\261", 0, QApplication::UnicodeUTF8));
        Num9->setText(QApplication::translate("MainWindow", "9", 0, QApplication::UnicodeUTF8));
        Num3->setText(QApplication::translate("MainWindow", "3", 0, QApplication::UnicodeUTF8));
        Num6->setText(QApplication::translate("MainWindow", "6", 0, QApplication::UnicodeUTF8));
        ButtonMod->setText(QApplication::translate("MainWindow", "\357\274\205", 0, QApplication::UnicodeUTF8));
        Num0->setText(QApplication::translate("MainWindow", "0", 0, QApplication::UnicodeUTF8));
        ButtonPt->setText(QApplication::translate("MainWindow", "\302\267", 0, QApplication::UnicodeUTF8));
        ButtonEq->setText(QApplication::translate("MainWindow", "\357\274\235", 0, QApplication::UnicodeUTF8));
        menu->setTitle(QApplication::translate("MainWindow", "\345\205\263\344\272\216", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
